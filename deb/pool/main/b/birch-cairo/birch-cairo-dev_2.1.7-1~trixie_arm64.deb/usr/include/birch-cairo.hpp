#ifndef BIRCH_CAIRO_HPP
#define BIRCH_CAIRO_HPP

#include <numbirch.hpp>

#include <membirch.hpp>

#include <birch-standard.hpp>
namespace birch {
#line 3 "src/Context.birch"
class Context_;
#line 3 "src/Context.birch"
using Context = membirch::Shared<Context_>;
#line 1 "src/Pattern.birch"
class Pattern_;
#line 1 "src/Pattern.birch"
using Pattern = membirch::Shared<Pattern_>;
#line 1 "src/Surface.birch"
class Surface_;
#line 1 "src/Surface.birch"
using Surface = membirch::Shared<Surface_>;
#line 3 "src/SurfacePDF.birch"
class SurfacePDF_;
#line 3 "src/SurfacePDF.birch"
using SurfacePDF = membirch::Shared<SurfacePDF_>;
#line 1 "src/SurfacePNG.birch"
class SurfacePNG_;
#line 1 "src/SurfacePNG.birch"
using SurfacePNG = membirch::Shared<SurfacePNG_>;
#line 3 "src/SurfaceSVG.birch"
class SurfaceSVG_;
#line 3 "src/SurfaceSVG.birch"
using SurfaceSVG = membirch::Shared<SurfaceSVG_>;



}
#line 1 "src/Context.birch"

#include <cairo/cairo.h>
#line 1 "src/SurfacePDF.birch"

#include <cairo/cairo-pdf.h>
#line 1 "src/SurfaceSVG.birch"

#include <cairo/cairo-svg.h>
namespace birch{

/**
 *
 */
#line 280 "src/Context.birch"
Context create(const Surface& surface);

/**
 *
 */
#line 42 "src/Pattern.birch"
Pattern createRGB(const Real& red, const Real& green, const Real& blue);

/**
 *
 */
#line 53 "src/Pattern.birch"
Pattern createRGBA(const Real& red, const Real& green, const Real& blue, const Real& alpha);

/**
 *
 */
#line 64 "src/Pattern.birch"
Pattern createLinear(const Real& x0, const Real& y0, const Real& x1, const Real& y1);

/**
 *
 */
#line 75 "src/Pattern.birch"
Pattern createRadial(const Real& cx0, const Real& cy0, const Real& radius0, const Real& cx1, const Real& cy1, const Real& radius1);

/**
 *
 */
#line 15 "src/SurfacePDF.birch"
Surface createPDF(const String& filename, const Real& widthInPoints, const Real& heightInPoints);

/**
 *
 */
#line 23 "src/SurfacePNG.birch"
Surface createPNG(const String& filename, const Integer& width, const Integer& height);

/**
 *
 */
#line 15 "src/SurfaceSVG.birch"
Surface createSVG(const String& filename, const Real& widthInPoints, const Real& heightInPoints);

/**
 * Cairo graphics context.
 */
#line 3 "src/Context.birch"
class Context_ : public Object_ {
public:
  #line 3 "src/Context.birch"
  MEMBIRCH_CLASS(Context_, Object_)
  #line 3 "src/Context.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 3 "src/Context.birch"
  using base_type_::operator=;
  
  #line 3 "src/Context.birch"
  Context_();

  #line 9 "src/Context.birch"

  cairo_t* cr;
    
  /**
   *
   */
  #line 16 "src/Context.birch"
  virtual void destroy();
  
  /**
   *
   */
  #line 25 "src/Context.birch"
  virtual void newPath();
  
  /**
   *
   */
  #line 34 "src/Context.birch"
  virtual void closePath();
  
  /**
   *
   */
  #line 43 "src/Context.birch"
  virtual void arc(const Real& xc, const Real& yc, const Real& radius, const Real& angle1, const Real& angle2);
  
  /**
   *
   */
  #line 52 "src/Context.birch"
  virtual void arcNegative(const Real& xc, const Real& yc, const Real& radius, const Real& angle1, const Real& angle2);
  
  /**
   *
   */
  #line 61 "src/Context.birch"
  virtual void curveTo(const Real& x1, const Real& y1, const Real& x2, const Real& y2, const Real& x3, const Real& y3);
  
  /**
   *
   */
  #line 70 "src/Context.birch"
  virtual void lineTo(const Real& x, const Real& y);
  
  /**
   *
   */
  #line 79 "src/Context.birch"
  virtual void moveTo(const Real& x, const Real& y);
  
  /**
   *
   */
  #line 88 "src/Context.birch"
  virtual void rectangle(const Real& x, const Real& y, const Real& width, const Real& height);
  
  /**
   *
   */
  #line 97 "src/Context.birch"
  virtual void relCurveTo(const Real& dx1, const Real& dy1, const Real& dx2, const Real& dy2, const Real& dx3, const Real& dy3);
  
  /**
   *
   */
  #line 106 "src/Context.birch"
  virtual void relLineTo(const Real& dx, const Real& dy);
  
  /**
   *
   */
  #line 115 "src/Context.birch"
  virtual void relMoveTo(const Real& dx, const Real& dy);
  
  /**
   *
   */
  #line 124 "src/Context.birch"
  virtual void stroke();
  
  /**
   *
   */
  #line 133 "src/Context.birch"
  virtual void strokePreserve();
  
  /**
   *
   */
  #line 142 "src/Context.birch"
  virtual void fill();
  
  /**
   *
   */
  #line 151 "src/Context.birch"
  virtual void fillPreserve();
  
  /**
   *
   */
  #line 160 "src/Context.birch"
  virtual void paint();
  
  /**
   *
   */
  #line 169 "src/Context.birch"
  virtual void translate(const Real& tx, const Real& ty);
  
  /**
   *
   */
  #line 178 "src/Context.birch"
  virtual void scale(const Real& sx, const Real& sy);
  
  /**
   *
   */
  #line 187 "src/Context.birch"
  virtual void rotate(const Real& angle);
  
  /**
   *
   */
  #line 196 "src/Context.birch"
  virtual std::tuple<Real, Real> deviceToUserDistance(const Real& ux, const Real& uy);
  
  /**
   *
   */
  #line 207 "src/Context.birch"
  virtual void setSourceRGB(const Real& red, const Real& green, const Real& blue);
  
  /**
   *
   */
  #line 216 "src/Context.birch"
  virtual void setSourceRGBA(const Real& red, const Real& green, const Real& blue, const Real& alpha);
  
  /**
   *
   */
  #line 225 "src/Context.birch"
  virtual void setSource(const Pattern& pattern);
  
  /**
   *
   */
  #line 234 "src/Context.birch"
  virtual void setLineWidth(const Real& width);
  
  /**
   *
   */
  #line 243 "src/Context.birch"
  virtual void showText(const String& utf8);
  
  /**
   *
   */
  #line 252 "src/Context.birch"
  virtual void setFontSize(const Real& size);
  
  /**
   *
   */
  #line 261 "src/Context.birch"
  virtual void pushGroup();
  
  /**
   *
   */
  #line 270 "src/Context.birch"
  virtual void popGroupToSource();
};

#line 3 "src/Context.birch"
Object_* make_Context_();


/**
 * Cairo pattern.
 */
#line 1 "src/Pattern.birch"
class Pattern_ : public Object_ {
public:
  #line 1 "src/Pattern.birch"
  MEMBIRCH_CLASS(Pattern_, Object_)
  #line 1 "src/Pattern.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 1 "src/Pattern.birch"
  using base_type_::operator=;
  
  #line 1 "src/Pattern.birch"
  Pattern_();

  #line 5 "src/Pattern.birch"

  cairo_pattern_t* pattern;
    
  /**
   *
   */
  #line 12 "src/Pattern.birch"
  virtual void addColorStopRGB(const Real& offset, const Real& red, const Real& green, const Real& blue);
  
  /**
   *
   */
  #line 21 "src/Pattern.birch"
  virtual void addColorStopRGBA(const Real& offset, const Real& red, const Real& green, const Real& blue, const Real& alpha);
  
  /**
   *
   */
  #line 32 "src/Pattern.birch"
  virtual void destroy();
};

#line 1 "src/Pattern.birch"
Object_* make_Pattern_();


/**
 * Cairo surface.
 */
#line 1 "src/Surface.birch"
class Surface_ : public Object_ {
public:
  #line 1 "src/Surface.birch"
  MEMBIRCH_CLASS(Surface_, Object_)
  #line 1 "src/Surface.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 1 "src/Surface.birch"
  using base_type_::operator=;
  
  #line 1 "src/Surface.birch"
  Surface_();

  #line 5 "src/Surface.birch"

  cairo_surface_t* surface;
    
  /**
   *
   */
  #line 12 "src/Surface.birch"
  virtual void destroy();
};

#line 1 "src/Surface.birch"
Object_* make_Surface_();


/**
 * A PDF surface. This extends the usual Cairo interface.
 */
#line 3 "src/SurfacePDF.birch"
class SurfacePDF_ : public membirch::unwrap_pointer<Surface>::type {
public:
  #line 3 "src/SurfacePDF.birch"
  MEMBIRCH_CLASS(SurfacePDF_, typename membirch::unwrap_pointer<Surface>::type)
  #line 3 "src/SurfacePDF.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 3 "src/SurfacePDF.birch"
  using base_type_::operator=;
  
  #line 3 "src/SurfacePDF.birch"
  SurfacePDF_();

};

#line 3 "src/SurfacePDF.birch"
Object_* make_SurfacePDF_();


/**
 * A PNG surface. This extends the usual Cairo interface.
 */
#line 1 "src/SurfacePNG.birch"
class SurfacePNG_ : public membirch::unwrap_pointer<Surface>::type {
public:
  #line 1 "src/SurfacePNG.birch"
  MEMBIRCH_CLASS(SurfacePNG_, typename membirch::unwrap_pointer<Surface>::type)
  #line 1 "src/SurfacePNG.birch"
  MEMBIRCH_CLASS_MEMBERS(filename)
  #line 1 "src/SurfacePNG.birch"
  using base_type_::operator=;
  #line 1 "src/SurfacePNG.birch"
  using base_type_::destroy;
  
  #line 1 "src/SurfacePNG.birch"
  SurfacePNG_();

  String filename;
  
  /**
   *
   */
  #line 10 "src/SurfacePNG.birch"
  virtual void destroy() override;
};

#line 1 "src/SurfacePNG.birch"
Object_* make_SurfacePNG_();


/**
 * An SVG surface. This extends the usual Cairo interface.
 */
#line 3 "src/SurfaceSVG.birch"
class SurfaceSVG_ : public membirch::unwrap_pointer<Surface>::type {
public:
  #line 3 "src/SurfaceSVG.birch"
  MEMBIRCH_CLASS(SurfaceSVG_, typename membirch::unwrap_pointer<Surface>::type)
  #line 3 "src/SurfaceSVG.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 3 "src/SurfaceSVG.birch"
  using base_type_::operator=;
  
  #line 3 "src/SurfaceSVG.birch"
  SurfaceSVG_();

};

#line 3 "src/SurfaceSVG.birch"
Object_* make_SurfaceSVG_();

}

#endif
