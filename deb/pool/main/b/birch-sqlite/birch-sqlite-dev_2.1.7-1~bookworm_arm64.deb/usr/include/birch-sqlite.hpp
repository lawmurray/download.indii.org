#ifndef BIRCH_SQLITE_HPP
#define BIRCH_SQLITE_HPP

#include <numbirch.hpp>

#include <membirch.hpp>

#include <birch-standard.hpp>
namespace birch {
#line 3 "src/SQLite3.birch"
class SQLite3_;
#line 3 "src/SQLite3.birch"
using SQLite3 = membirch::Shared<SQLite3_>;
#line 1 "src/SQLite3Statement.birch"
class SQLite3Statement_;
#line 1 "src/SQLite3Statement.birch"
using SQLite3Statement = membirch::Shared<SQLite3Statement_>;



}
#line 1 "src/SQLite3.birch"

#include <sqlite3.h>
namespace birch{

/**
 * Wrapper for [sqlite3](https://www.sqlite.org/c3ref/sqlite3.html) struct.
 */
#line 3 "src/SQLite3.birch"
class SQLite3_ : public Object_ {
public:
  #line 3 "src/SQLite3.birch"
  MEMBIRCH_CLASS(SQLite3_, Object_)
  #line 3 "src/SQLite3.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 3 "src/SQLite3.birch"
  using base_type_::operator=;
  
  #line 3 "src/SQLite3.birch"
  SQLite3_();

  #line 9 "src/SQLite3.birch"

  sqlite3* db = nullptr;
    
  /**
   *
   */
  #line 16 "src/SQLite3.birch"
  virtual void open(const String& filename);
  
  /**
   *
   */
  #line 29 "src/SQLite3.birch"
  virtual void close();
  
  /**
   * 
   */
  #line 42 "src/SQLite3.birch"
  virtual SQLite3Statement prepare(const String& sql);
  
  /**
   *
   */
  #line 56 "src/SQLite3.birch"
  virtual void exec(const String& sql);
};

#line 3 "src/SQLite3.birch"
Object_* make_SQLite3_();


/**
 * Wrapper for [sqlite3_stmt](https://www.sqlite.org/c3ref/stmt.html) struct.
 */
#line 1 "src/SQLite3Statement.birch"
class SQLite3Statement_ : public Object_ {
public:
  #line 1 "src/SQLite3Statement.birch"
  MEMBIRCH_CLASS(SQLite3Statement_, Object_)
  #line 1 "src/SQLite3Statement.birch"
  MEMBIRCH_CLASS_MEMBERS(MEMBIRCH_NO_MEMBERS)
  #line 1 "src/SQLite3Statement.birch"
  using base_type_::operator=;
  
  #line 1 "src/SQLite3Statement.birch"
  SQLite3Statement_();

  #line 5 "src/SQLite3Statement.birch"

  sqlite3_stmt* stmt = nullptr;
    
  /**
   * Bind argument to a parameter.
   *
   * - i: Parameter index, 1-based.
   * - x: Argument.
   */
  #line 15 "src/SQLite3Statement.birch"
  virtual void bind(const Integer& i, const Integer& x);
  
  /**
   * Bind argument to a parameter.
   *
   * - i: Parameter index, 1-based.
   * - x: Argument.
   */
  #line 30 "src/SQLite3Statement.birch"
  virtual void bind(const Integer& i, const Real& x);
  
  /**
   * Bind argument to a parameter.
   *
   * - i: Parameter index, 1-based.
   * - x: Argument.
   */
  #line 45 "src/SQLite3Statement.birch"
  virtual void bind(const Integer& i, const String& x);
  
  /**
   * Bind null argument to a parameter.
   *
   * - i: Parameter index, 1-based.
   */
  #line 60 "src/SQLite3Statement.birch"
  virtual void bindNull(const Integer& i);
  
  /**
   * Execute the statement one step. For a query, this returns true if there
   * is a new row to read (using the `column*` functions) and false if there
   * are no more rows to read. For an update, this returns false on success
   * (as there are no results to read). Anything else throws an error.
   *
   * Intenally, this is a simplified version of
   * [sqlite3_step](https://www.sqlite.org/c3ref/step.html). If
   * `sqlite3_step` returns:
   *
   *   * `SQL_ROW` it returns true,
   *   * `SQL_DONE` it returns false, and
   *   * anything else, throws and error.
   */
  #line 83 "src/SQLite3Statement.birch"
  virtual Boolean step();
  
  /**
   * Number of columns in the result.
   */
  #line 96 "src/SQLite3Statement.birch"
  virtual Integer columnCount();
  
  /**
   * Get column value as an integer.
   *
   * - i: Column index, 1-based.
   *
   * Return: Optional with a value if the column value is a non-null integer.
   */
  #line 109 "src/SQLite3Statement.birch"
  virtual std::optional<Integer> columnInteger(const Integer& i);
  
  /**
   * Get column value as a real.
   *
   * - i: Column index, 1-based.
   *
   * Return: Optional with a value if the column value is a non-null real.
   */
  #line 125 "src/SQLite3Statement.birch"
  virtual std::optional<Real> columnReal(const Integer& i);
  
  /**
   * Get column value as a string.
   *
   * - i: Column index, 1-based.
   *
   * Return: Optional with a value if the column value is a non-null string.
   */
  #line 141 "src/SQLite3Statement.birch"
  virtual std::optional<String> columnString(const Integer& i);
  
  /**
   * Is the column value `null`?
   *
   * - i: Column index, 1-based.
   */
  #line 155 "src/SQLite3Statement.birch"
  virtual Boolean columnNull(const Integer& i);
  
  /**
   * Reset the statement for reuse.
   */
  #line 164 "src/SQLite3Statement.birch"
  virtual void reset();
  
  /**
   * Finalize the statement.
   */
  #line 176 "src/SQLite3Statement.birch"
  virtual void finalize();
};

#line 1 "src/SQLite3Statement.birch"
Object_* make_SQLite3Statement_();

}

#endif
