/**
 * MemBirch.
 */
namespace membirch {
  //
}
