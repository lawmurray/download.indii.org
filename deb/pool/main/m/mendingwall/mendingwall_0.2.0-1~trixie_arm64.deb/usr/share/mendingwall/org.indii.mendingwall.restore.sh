#!/usr/bin/env sh

/usr/bin/mendingwalld --restore
