#!/usr/bin/env sh

/usr/bin/mendingwallcli --restore
